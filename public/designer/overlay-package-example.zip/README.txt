ScoreSync overlay package — example
===================================

Zip these files (overlay.json at the top level) and import the .zip in
Designer -> "Import animated package".

  overlay.json   manifest: format, version, name, canvas, layers, fonts…
  index.html     markup. A whole HTML page is fine: <link>ed CSS from the
                 package and <style> blocks are pulled in, <body> is kept.
  style.css      styles and @keyframes animations
  assets/        images (png, jpg, webp, gif, svg) — use relative paths
  fonts/         .woff2 fonts — list them in overlay.json "fonts", or use
                 @font-face { font-family: "X"; src: url(fonts/x.woff2) }

Rules
  * CSS animation only: JavaScript files and <script> tags are removed.
  * No event handlers (onclick=…), iframes, forms, @import, external CSS.
  * Live data: {{derived.teams[0].teamName|upper}}, {{derived.teams[0].totalPoints}}
  * "layers" is optional; without it index.html + style.css become one
    full-canvas layer.
  * Limits: 24 MB zip, 200 files, 20 layers, 60 000 characters of HTML
    and of CSS per layer, 4 MB per image.

A design exported from the Designer ("Export as package") is the same
format with "kind": "design" and a design.json — anyone can import it.
